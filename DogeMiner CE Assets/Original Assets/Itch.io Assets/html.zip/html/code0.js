gdjs.EarthCode = {};
gdjs.EarthCode.GDBackground_9595_9595Earth_9595Objects1= [];
gdjs.EarthCode.GDBackground_9595_9595Earth_9595Objects2= [];
gdjs.EarthCode.GDBackground_9595_9595Earth_9595Objects3= [];
gdjs.EarthCode.GDBackground_9595_9595Earth_9595Objects4= [];
gdjs.EarthCode.GDBackground_9595_9595Earth_9595Objects5= [];
gdjs.EarthCode.GDEarth_9595UIObjects1= [];
gdjs.EarthCode.GDEarth_9595UIObjects2= [];
gdjs.EarthCode.GDEarth_9595UIObjects3= [];
gdjs.EarthCode.GDEarth_9595UIObjects4= [];
gdjs.EarthCode.GDEarth_9595UIObjects5= [];
gdjs.EarthCode.GDReddit_9595ButtonObjects1= [];
gdjs.EarthCode.GDReddit_9595ButtonObjects2= [];
gdjs.EarthCode.GDReddit_9595ButtonObjects3= [];
gdjs.EarthCode.GDReddit_9595ButtonObjects4= [];
gdjs.EarthCode.GDReddit_9595ButtonObjects5= [];
gdjs.EarthCode.GDReddit_9595LogoObjects1= [];
gdjs.EarthCode.GDReddit_9595LogoObjects2= [];
gdjs.EarthCode.GDReddit_9595LogoObjects3= [];
gdjs.EarthCode.GDReddit_9595LogoObjects4= [];
gdjs.EarthCode.GDReddit_9595LogoObjects5= [];
gdjs.EarthCode.GDDiscord_9595ButtonObjects1= [];
gdjs.EarthCode.GDDiscord_9595ButtonObjects2= [];
gdjs.EarthCode.GDDiscord_9595ButtonObjects3= [];
gdjs.EarthCode.GDDiscord_9595ButtonObjects4= [];
gdjs.EarthCode.GDDiscord_9595ButtonObjects5= [];
gdjs.EarthCode.GDDiscord_9595LogoObjects1= [];
gdjs.EarthCode.GDDiscord_9595LogoObjects2= [];
gdjs.EarthCode.GDDiscord_9595LogoObjects3= [];
gdjs.EarthCode.GDDiscord_9595LogoObjects4= [];
gdjs.EarthCode.GDDiscord_9595LogoObjects5= [];
gdjs.EarthCode.GDSteamGroup_9595ButtonObjects1= [];
gdjs.EarthCode.GDSteamGroup_9595ButtonObjects2= [];
gdjs.EarthCode.GDSteamGroup_9595ButtonObjects3= [];
gdjs.EarthCode.GDSteamGroup_9595ButtonObjects4= [];
gdjs.EarthCode.GDSteamGroup_9595ButtonObjects5= [];
gdjs.EarthCode.GDSteamGroup_9595LogoObjects1= [];
gdjs.EarthCode.GDSteamGroup_9595LogoObjects2= [];
gdjs.EarthCode.GDSteamGroup_9595LogoObjects3= [];
gdjs.EarthCode.GDSteamGroup_9595LogoObjects4= [];
gdjs.EarthCode.GDSteamGroup_9595LogoObjects5= [];
gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects1= [];
gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects2= [];
gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects3= [];
gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects4= [];
gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects5= [];
gdjs.EarthCode.GDItch_9595IO_9595LogoObjects1= [];
gdjs.EarthCode.GDItch_9595IO_9595LogoObjects2= [];
gdjs.EarthCode.GDItch_9595IO_9595LogoObjects3= [];
gdjs.EarthCode.GDItch_9595IO_9595LogoObjects4= [];
gdjs.EarthCode.GDItch_9595IO_9595LogoObjects5= [];
gdjs.EarthCode.GDGameJolt_9595ButtonObjects1= [];
gdjs.EarthCode.GDGameJolt_9595ButtonObjects2= [];
gdjs.EarthCode.GDGameJolt_9595ButtonObjects3= [];
gdjs.EarthCode.GDGameJolt_9595ButtonObjects4= [];
gdjs.EarthCode.GDGameJolt_9595ButtonObjects5= [];
gdjs.EarthCode.GDGameJolt_9595LogoObjects1= [];
gdjs.EarthCode.GDGameJolt_9595LogoObjects2= [];
gdjs.EarthCode.GDGameJolt_9595LogoObjects3= [];
gdjs.EarthCode.GDGameJolt_9595LogoObjects4= [];
gdjs.EarthCode.GDGameJolt_9595LogoObjects5= [];
gdjs.EarthCode.GDSocial_9595Media_9595TextObjects1= [];
gdjs.EarthCode.GDSocial_9595Media_9595TextObjects2= [];
gdjs.EarthCode.GDSocial_9595Media_9595TextObjects3= [];
gdjs.EarthCode.GDSocial_9595Media_9595TextObjects4= [];
gdjs.EarthCode.GDSocial_9595Media_9595TextObjects5= [];
gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects1= [];
gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects2= [];
gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects3= [];
gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects4= [];
gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects5= [];
gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects1= [];
gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects2= [];
gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects3= [];
gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects4= [];
gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects5= [];
gdjs.EarthCode.GDDoge_9595ButtonObjects1= [];
gdjs.EarthCode.GDDoge_9595ButtonObjects2= [];
gdjs.EarthCode.GDDoge_9595ButtonObjects3= [];
gdjs.EarthCode.GDDoge_9595ButtonObjects4= [];
gdjs.EarthCode.GDDoge_9595ButtonObjects5= [];
gdjs.EarthCode.GDDogeCoinsObjects1= [];
gdjs.EarthCode.GDDogeCoinsObjects2= [];
gdjs.EarthCode.GDDogeCoinsObjects3= [];
gdjs.EarthCode.GDDogeCoinsObjects4= [];
gdjs.EarthCode.GDDogeCoinsObjects5= [];
gdjs.EarthCode.GDDogeCoin_9595LogoObjects1= [];
gdjs.EarthCode.GDDogeCoin_9595LogoObjects2= [];
gdjs.EarthCode.GDDogeCoin_9595LogoObjects3= [];
gdjs.EarthCode.GDDogeCoin_9595LogoObjects4= [];
gdjs.EarthCode.GDDogeCoin_9595LogoObjects5= [];
gdjs.EarthCode.GDDogeCoin_9595AmountObjects1= [];
gdjs.EarthCode.GDDogeCoin_9595AmountObjects2= [];
gdjs.EarthCode.GDDogeCoin_9595AmountObjects3= [];
gdjs.EarthCode.GDDogeCoin_9595AmountObjects4= [];
gdjs.EarthCode.GDDogeCoin_9595AmountObjects5= [];
gdjs.EarthCode.GDEarth_9595ButtonObjects1= [];
gdjs.EarthCode.GDEarth_9595ButtonObjects2= [];
gdjs.EarthCode.GDEarth_9595ButtonObjects3= [];
gdjs.EarthCode.GDEarth_9595ButtonObjects4= [];
gdjs.EarthCode.GDEarth_9595ButtonObjects5= [];
gdjs.EarthCode.GDThingaMaBobbaObjects1= [];
gdjs.EarthCode.GDThingaMaBobbaObjects2= [];
gdjs.EarthCode.GDThingaMaBobbaObjects3= [];
gdjs.EarthCode.GDThingaMaBobbaObjects4= [];
gdjs.EarthCode.GDThingaMaBobbaObjects5= [];
gdjs.EarthCode.GDShibe_9595AnimObjects1= [];
gdjs.EarthCode.GDShibe_9595AnimObjects2= [];
gdjs.EarthCode.GDShibe_9595AnimObjects3= [];
gdjs.EarthCode.GDShibe_9595AnimObjects4= [];
gdjs.EarthCode.GDShibe_9595AnimObjects5= [];
gdjs.EarthCode.GDShibeObjects1= [];
gdjs.EarthCode.GDShibeObjects2= [];
gdjs.EarthCode.GDShibeObjects3= [];
gdjs.EarthCode.GDShibeObjects4= [];
gdjs.EarthCode.GDShibeObjects5= [];
gdjs.EarthCode.GDShibe_9595Alt_9595TextObjects1= [];
gdjs.EarthCode.GDShibe_9595Alt_9595TextObjects2= [];
gdjs.EarthCode.GDShibe_9595Alt_9595TextObjects3= [];
gdjs.EarthCode.GDShibe_9595Alt_9595TextObjects4= [];
gdjs.EarthCode.GDShibe_9595Alt_9595TextObjects5= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects1= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects3= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects4= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects5= [];
gdjs.EarthCode.GDSquareWhiteSliderObjects1= [];
gdjs.EarthCode.GDSquareWhiteSliderObjects2= [];
gdjs.EarthCode.GDSquareWhiteSliderObjects3= [];
gdjs.EarthCode.GDSquareWhiteSliderObjects4= [];
gdjs.EarthCode.GDSquareWhiteSliderObjects5= [];
gdjs.EarthCode.GDVolume_9595TextObjects1= [];
gdjs.EarthCode.GDVolume_9595TextObjects2= [];
gdjs.EarthCode.GDVolume_9595TextObjects3= [];
gdjs.EarthCode.GDVolume_9595TextObjects4= [];
gdjs.EarthCode.GDVolume_9595TextObjects5= [];
gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects1= [];
gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects2= [];
gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects3= [];
gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects4= [];
gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects5= [];
gdjs.EarthCode.GDEnable_9595Rock_9595Hitting_9595TextObjects1= [];
gdjs.EarthCode.GDEnable_9595Rock_9595Hitting_9595TextObjects2= [];
gdjs.EarthCode.GDEnable_9595Rock_9595Hitting_9595TextObjects3= [];
gdjs.EarthCode.GDEnable_9595Rock_9595Hitting_9595TextObjects4= [];
gdjs.EarthCode.GDEnable_9595Rock_9595Hitting_9595TextObjects5= [];
gdjs.EarthCode.GDTotal_9595DPSObjects1= [];
gdjs.EarthCode.GDTotal_9595DPSObjects2= [];
gdjs.EarthCode.GDTotal_9595DPSObjects3= [];
gdjs.EarthCode.GDTotal_9595DPSObjects4= [];
gdjs.EarthCode.GDTotal_9595DPSObjects5= [];
gdjs.EarthCode.GDDPS_9595LogoObjects1= [];
gdjs.EarthCode.GDDPS_9595LogoObjects2= [];
gdjs.EarthCode.GDDPS_9595LogoObjects3= [];
gdjs.EarthCode.GDDPS_9595LogoObjects4= [];
gdjs.EarthCode.GDDPS_9595LogoObjects5= [];
gdjs.EarthCode.GDDPS_9595AmountObjects1= [];
gdjs.EarthCode.GDDPS_9595AmountObjects2= [];
gdjs.EarthCode.GDDPS_9595AmountObjects3= [];
gdjs.EarthCode.GDDPS_9595AmountObjects4= [];
gdjs.EarthCode.GDDPS_9595AmountObjects5= [];
gdjs.EarthCode.GDMining_9595Shibe_9595DPSObjects1= [];
gdjs.EarthCode.GDMining_9595Shibe_9595DPSObjects2= [];
gdjs.EarthCode.GDMining_9595Shibe_9595DPSObjects3= [];
gdjs.EarthCode.GDMining_9595Shibe_9595DPSObjects4= [];
gdjs.EarthCode.GDMining_9595Shibe_9595DPSObjects5= [];
gdjs.EarthCode.GDMusic_9595ToggleObjects1= [];
gdjs.EarthCode.GDMusic_9595ToggleObjects2= [];
gdjs.EarthCode.GDMusic_9595ToggleObjects3= [];
gdjs.EarthCode.GDMusic_9595ToggleObjects4= [];
gdjs.EarthCode.GDMusic_9595ToggleObjects5= [];
gdjs.EarthCode.GDToggle_9595Music_9595TextObjects1= [];
gdjs.EarthCode.GDToggle_9595Music_9595TextObjects2= [];
gdjs.EarthCode.GDToggle_9595Music_9595TextObjects3= [];
gdjs.EarthCode.GDToggle_9595Music_9595TextObjects4= [];
gdjs.EarthCode.GDToggle_9595Music_9595TextObjects5= [];
gdjs.EarthCode.GDDoge_9595KennelsObjects1= [];
gdjs.EarthCode.GDDoge_9595KennelsObjects2= [];
gdjs.EarthCode.GDDoge_9595KennelsObjects3= [];
gdjs.EarthCode.GDDoge_9595KennelsObjects4= [];
gdjs.EarthCode.GDDoge_9595KennelsObjects5= [];
gdjs.EarthCode.GDKennelObjects1= [];
gdjs.EarthCode.GDKennelObjects2= [];
gdjs.EarthCode.GDKennelObjects3= [];
gdjs.EarthCode.GDKennelObjects4= [];
gdjs.EarthCode.GDKennelObjects5= [];
gdjs.EarthCode.GDKennel_9595Alt_9595TextObjects1= [];
gdjs.EarthCode.GDKennel_9595Alt_9595TextObjects2= [];
gdjs.EarthCode.GDKennel_9595Alt_9595TextObjects3= [];
gdjs.EarthCode.GDKennel_9595Alt_9595TextObjects4= [];
gdjs.EarthCode.GDKennel_9595Alt_9595TextObjects5= [];
gdjs.EarthCode.GDDoge_9595Kennel_9595DPSObjects1= [];
gdjs.EarthCode.GDDoge_9595Kennel_9595DPSObjects2= [];
gdjs.EarthCode.GDDoge_9595Kennel_9595DPSObjects3= [];
gdjs.EarthCode.GDDoge_9595Kennel_9595DPSObjects4= [];
gdjs.EarthCode.GDDoge_9595Kennel_9595DPSObjects5= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects1= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects3= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects4= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects5= [];
gdjs.EarthCode.GDDogeKennel_9595Base_9595ProperObjects1= [];
gdjs.EarthCode.GDDogeKennel_9595Base_9595ProperObjects2= [];
gdjs.EarthCode.GDDogeKennel_9595Base_9595ProperObjects3= [];
gdjs.EarthCode.GDDogeKennel_9595Base_9595ProperObjects4= [];
gdjs.EarthCode.GDDogeKennel_9595Base_9595ProperObjects5= [];
gdjs.EarthCode.GDSlave_9595KittensObjects1= [];
gdjs.EarthCode.GDSlave_9595KittensObjects2= [];
gdjs.EarthCode.GDSlave_9595KittensObjects3= [];
gdjs.EarthCode.GDSlave_9595KittensObjects4= [];
gdjs.EarthCode.GDSlave_9595KittensObjects5= [];
gdjs.EarthCode.GDSlave_9595Kittens2Objects1= [];
gdjs.EarthCode.GDSlave_9595Kittens2Objects2= [];
gdjs.EarthCode.GDSlave_9595Kittens2Objects3= [];
gdjs.EarthCode.GDSlave_9595Kittens2Objects4= [];
gdjs.EarthCode.GDSlave_9595Kittens2Objects5= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects1= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects3= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects4= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects5= [];
gdjs.EarthCode.GDSlave_9595Kitten_9595Alt_9595TextObjects1= [];
gdjs.EarthCode.GDSlave_9595Kitten_9595Alt_9595TextObjects2= [];
gdjs.EarthCode.GDSlave_9595Kitten_9595Alt_9595TextObjects3= [];
gdjs.EarthCode.GDSlave_9595Kitten_9595Alt_9595TextObjects4= [];
gdjs.EarthCode.GDSlave_9595Kitten_9595Alt_9595TextObjects5= [];
gdjs.EarthCode.GDSlave_9595Kittten_9595DPSObjects1= [];
gdjs.EarthCode.GDSlave_9595Kittten_9595DPSObjects2= [];
gdjs.EarthCode.GDSlave_9595Kittten_9595DPSObjects3= [];
gdjs.EarthCode.GDSlave_9595Kittten_9595DPSObjects4= [];
gdjs.EarthCode.GDSlave_9595Kittten_9595DPSObjects5= [];
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects1= [];
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2= [];
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects3= [];
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects4= [];
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects5= [];
gdjs.EarthCode.GDToggle_9595Buy_9595Sounds_9595TextObjects1= [];
gdjs.EarthCode.GDToggle_9595Buy_9595Sounds_9595TextObjects2= [];
gdjs.EarthCode.GDToggle_9595Buy_9595Sounds_9595TextObjects3= [];
gdjs.EarthCode.GDToggle_9595Buy_9595Sounds_9595TextObjects4= [];
gdjs.EarthCode.GDToggle_9595Buy_9595Sounds_9595TextObjects5= [];
gdjs.EarthCode.GDMoon_9595RocketObjects1= [];
gdjs.EarthCode.GDMoon_9595RocketObjects2= [];
gdjs.EarthCode.GDMoon_9595RocketObjects3= [];
gdjs.EarthCode.GDMoon_9595RocketObjects4= [];
gdjs.EarthCode.GDMoon_9595RocketObjects5= [];
gdjs.EarthCode.GDMoon_9595Rocket_9595Price_9595TEXTObjects1= [];
gdjs.EarthCode.GDMoon_9595Rocket_9595Price_9595TEXTObjects2= [];
gdjs.EarthCode.GDMoon_9595Rocket_9595Price_9595TEXTObjects3= [];
gdjs.EarthCode.GDMoon_9595Rocket_9595Price_9595TEXTObjects4= [];
gdjs.EarthCode.GDMoon_9595Rocket_9595Price_9595TEXTObjects5= [];
gdjs.EarthCode.GDmoon_9595rocket_9595alt_9595textObjects1= [];
gdjs.EarthCode.GDmoon_9595rocket_9595alt_9595textObjects2= [];
gdjs.EarthCode.GDmoon_9595rocket_9595alt_9595textObjects3= [];
gdjs.EarthCode.GDmoon_9595rocket_9595alt_9595textObjects4= [];
gdjs.EarthCode.GDmoon_9595rocket_9595alt_9595textObjects5= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects1= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects3= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects4= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects5= [];
gdjs.EarthCode.GDMoon_9595Rocket_9595DPSObjects1= [];
gdjs.EarthCode.GDMoon_9595Rocket_9595DPSObjects2= [];
gdjs.EarthCode.GDMoon_9595Rocket_9595DPSObjects3= [];
gdjs.EarthCode.GDMoon_9595Rocket_9595DPSObjects4= [];
gdjs.EarthCode.GDMoon_9595Rocket_9595DPSObjects5= [];
gdjs.EarthCode.GDPlus1Objects1= [];
gdjs.EarthCode.GDPlus1Objects2= [];
gdjs.EarthCode.GDPlus1Objects3= [];
gdjs.EarthCode.GDPlus1Objects4= [];
gdjs.EarthCode.GDPlus1Objects5= [];
gdjs.EarthCode.GDNot_9595AllowedObjects1= [];
gdjs.EarthCode.GDNot_9595AllowedObjects2= [];
gdjs.EarthCode.GDNot_9595AllowedObjects3= [];
gdjs.EarthCode.GDNot_9595AllowedObjects4= [];
gdjs.EarthCode.GDNot_9595AllowedObjects5= [];
gdjs.EarthCode.GDUpgrade_9595ButtonObjects1= [];
gdjs.EarthCode.GDUpgrade_9595ButtonObjects2= [];
gdjs.EarthCode.GDUpgrade_9595ButtonObjects3= [];
gdjs.EarthCode.GDUpgrade_9595ButtonObjects4= [];
gdjs.EarthCode.GDUpgrade_9595ButtonObjects5= [];
gdjs.EarthCode.GDHelpers_9595ButtonObjects1= [];
gdjs.EarthCode.GDHelpers_9595ButtonObjects2= [];
gdjs.EarthCode.GDHelpers_9595ButtonObjects3= [];
gdjs.EarthCode.GDHelpers_9595ButtonObjects4= [];
gdjs.EarthCode.GDHelpers_9595ButtonObjects5= [];
gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1= [];
gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects2= [];
gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects3= [];
gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects4= [];
gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects5= [];
gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects1= [];
gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects2= [];
gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects3= [];
gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects4= [];
gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects5= [];
gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects1= [];
gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects2= [];
gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects3= [];
gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects4= [];
gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects5= [];
gdjs.EarthCode.GDMoon_9595BaseObjects1= [];
gdjs.EarthCode.GDMoon_9595BaseObjects2= [];
gdjs.EarthCode.GDMoon_9595BaseObjects3= [];
gdjs.EarthCode.GDMoon_9595BaseObjects4= [];
gdjs.EarthCode.GDMoon_9595BaseObjects5= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects1= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects3= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects4= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects5= [];
gdjs.EarthCode.GDMoon_9595Base_9595TextObjects1= [];
gdjs.EarthCode.GDMoon_9595Base_9595TextObjects2= [];
gdjs.EarthCode.GDMoon_9595Base_9595TextObjects3= [];
gdjs.EarthCode.GDMoon_9595Base_9595TextObjects4= [];
gdjs.EarthCode.GDMoon_9595Base_9595TextObjects5= [];
gdjs.EarthCode.GDMoon_9595Base_9595Alt_9595TextObjects1= [];
gdjs.EarthCode.GDMoon_9595Base_9595Alt_9595TextObjects2= [];
gdjs.EarthCode.GDMoon_9595Base_9595Alt_9595TextObjects3= [];
gdjs.EarthCode.GDMoon_9595Base_9595Alt_9595TextObjects4= [];
gdjs.EarthCode.GDMoon_9595Base_9595Alt_9595TextObjects5= [];
gdjs.EarthCode.GDMoon_9595Base_9595DPS_9595TextObjects1= [];
gdjs.EarthCode.GDMoon_9595Base_9595DPS_9595TextObjects2= [];
gdjs.EarthCode.GDMoon_9595Base_9595DPS_9595TextObjects3= [];
gdjs.EarthCode.GDMoon_9595Base_9595DPS_9595TextObjects4= [];
gdjs.EarthCode.GDMoon_9595Base_9595DPS_9595TextObjects5= [];
gdjs.EarthCode.GDTime_9595Machine_9595AnimObjects1= [];
gdjs.EarthCode.GDTime_9595Machine_9595AnimObjects2= [];
gdjs.EarthCode.GDTime_9595Machine_9595AnimObjects3= [];
gdjs.EarthCode.GDTime_9595Machine_9595AnimObjects4= [];
gdjs.EarthCode.GDTime_9595Machine_9595AnimObjects5= [];
gdjs.EarthCode.GDTime_9595Machine_9595Mining_9595Rig_9595TextObjects1= [];
gdjs.EarthCode.GDTime_9595Machine_9595Mining_9595Rig_9595TextObjects2= [];
gdjs.EarthCode.GDTime_9595Machine_9595Mining_9595Rig_9595TextObjects3= [];
gdjs.EarthCode.GDTime_9595Machine_9595Mining_9595Rig_9595TextObjects4= [];
gdjs.EarthCode.GDTime_9595Machine_9595Mining_9595Rig_9595TextObjects5= [];
gdjs.EarthCode.GDTime_9595Machine_9595Alt_9595TextObjects1= [];
gdjs.EarthCode.GDTime_9595Machine_9595Alt_9595TextObjects2= [];
gdjs.EarthCode.GDTime_9595Machine_9595Alt_9595TextObjects3= [];
gdjs.EarthCode.GDTime_9595Machine_9595Alt_9595TextObjects4= [];
gdjs.EarthCode.GDTime_9595Machine_9595Alt_9595TextObjects5= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects1= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects2= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects3= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects4= [];
gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects5= [];
gdjs.EarthCode.GDTime_9595Machine_9595DPS_9595TextObjects1= [];
gdjs.EarthCode.GDTime_9595Machine_9595DPS_9595TextObjects2= [];
gdjs.EarthCode.GDTime_9595Machine_9595DPS_9595TextObjects3= [];
gdjs.EarthCode.GDTime_9595Machine_9595DPS_9595TextObjects4= [];
gdjs.EarthCode.GDTime_9595Machine_9595DPS_9595TextObjects5= [];


gdjs.EarthCode.eventsList0 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Discord_Button"), gdjs.EarthCode.GDDiscord_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Doge_Action__Default_Pick_"), gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects2);
gdjs.copyArray(runtimeScene.getObjects("Doge_Button"), gdjs.EarthCode.GDDoge_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("GameJolt_Button"), gdjs.EarthCode.GDGameJolt_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Itch_IO_Button"), gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Reddit_Button"), gdjs.EarthCode.GDReddit_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("SteamGroup_Button"), gdjs.EarthCode.GDSteamGroup_9595ButtonObjects2);
{for(var i = 0, len = gdjs.EarthCode.GDReddit_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.EarthCode.GDReddit_9595ButtonObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.EarthCode.GDDiscord_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.EarthCode.GDDiscord_9595ButtonObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.EarthCode.GDSteamGroup_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.EarthCode.GDSteamGroup_9595ButtonObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.EarthCode.GDGameJolt_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.EarthCode.GDGameJolt_9595ButtonObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.EarthCode.GDDoge_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.EarthCode.GDDoge_9595ButtonObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects2.length ;i < len;++i) {
    gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Reddit_Button"), gdjs.EarthCode.GDReddit_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDReddit_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDReddit_9595ButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDReddit_9595ButtonObjects2[k] = gdjs.EarthCode.GDReddit_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDReddit_9595ButtonObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://www.reddit.com/r/DogeMiner/", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Discord_Button"), gdjs.EarthCode.GDDiscord_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDDiscord_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDDiscord_9595ButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDDiscord_9595ButtonObjects2[k] = gdjs.EarthCode.GDDiscord_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDDiscord_9595ButtonObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://discord.gg/KPAjHmtD", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("SteamGroup_Button"), gdjs.EarthCode.GDSteamGroup_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDSteamGroup_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDSteamGroup_9595ButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDSteamGroup_9595ButtonObjects2[k] = gdjs.EarthCode.GDSteamGroup_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDSteamGroup_9595ButtonObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://steamcommunity.com/groups/dogeminergame", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Itch_IO_Button"), gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects2[k] = gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://babylion122.itch.io/dogeminer-ce", runtimeScene);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GameJolt_Button"), gdjs.EarthCode.GDGameJolt_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDGameJolt_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDGameJolt_9595ButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDGameJolt_9595ButtonObjects2[k] = gdjs.EarthCode.GDGameJolt_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDGameJolt_9595ButtonObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://gamejolt.com/c/dogeminer-r52saz", runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "o");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "g");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
}
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://dogeminer.se/", runtimeScene);
}}

}


};gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDPlus1Objects3Objects = Hashtable.newFrom({"Plus1": gdjs.EarthCode.GDPlus1Objects3});
gdjs.EarthCode.asyncCallback11218908 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Plus1"), gdjs.EarthCode.GDPlus1Objects5);

{for(var i = 0, len = gdjs.EarthCode.GDPlus1Objects5.length ;i < len;++i) {
    gdjs.EarthCode.GDPlus1Objects5[i].deleteFromScene(runtimeScene);
}
}}
gdjs.EarthCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.EarthCode.GDPlus1Objects4) asyncObjectsList.addObject("Plus1", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.EarthCode.asyncCallback11218908(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.EarthCode.asyncCallback11041756 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Plus1"), gdjs.EarthCode.GDPlus1Objects4);

{for(var i = 0, len = gdjs.EarthCode.GDPlus1Objects4.length ;i < len;++i) {
    gdjs.EarthCode.GDPlus1Objects4[i].getBehavior("Opacity").setOpacity(gdjs.EarthCode.GDPlus1Objects4[i].getBehavior("Opacity").getOpacity() - (50));
}
}
{ //Subevents
gdjs.EarthCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.EarthCode.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.EarthCode.GDPlus1Objects3) asyncObjectsList.addObject("Plus1", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.EarthCode.asyncCallback11041756(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.EarthCode.asyncCallback11142540 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Doge_Action__Default_Pick_"), gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Doge_IDLE__Default_Pick_"), gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects3);

gdjs.EarthCode.GDPlus1Objects3.length = 0;

{for(var i = 0, len = gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects3.length ;i < len;++i) {
    gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects3[i].hide();
}
}{for(var i = 0, len = gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects3.length ;i < len;++i) {
    gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDPlus1Objects3Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "Things that need to be on top of text", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "Things that need to be on top of text", 0), "Things that need to be on top of text");
}
{ //Subevents
gdjs.EarthCode.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.EarthCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects2) asyncObjectsList.addObject("Doge_Action__Default_Pick_", obj);
for (const obj of gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects2) asyncObjectsList.addObject("Doge_IDLE__Default_Pick_", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.EarthCode.asyncCallback11142540(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDPlus1Objects3Objects = Hashtable.newFrom({"Plus1": gdjs.EarthCode.GDPlus1Objects3});
gdjs.EarthCode.asyncCallback9306996 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Plus1"), gdjs.EarthCode.GDPlus1Objects5);

{for(var i = 0, len = gdjs.EarthCode.GDPlus1Objects5.length ;i < len;++i) {
    gdjs.EarthCode.GDPlus1Objects5[i].deleteFromScene(runtimeScene);
}
}}
gdjs.EarthCode.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.EarthCode.GDPlus1Objects4) asyncObjectsList.addObject("Plus1", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.EarthCode.asyncCallback9306996(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.EarthCode.asyncCallback11083892 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Plus1"), gdjs.EarthCode.GDPlus1Objects4);

{for(var i = 0, len = gdjs.EarthCode.GDPlus1Objects4.length ;i < len;++i) {
    gdjs.EarthCode.GDPlus1Objects4[i].getBehavior("Opacity").setOpacity(gdjs.EarthCode.GDPlus1Objects4[i].getBehavior("Opacity").getOpacity() - (50));
}
}
{ //Subevents
gdjs.EarthCode.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.EarthCode.eventsList5 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.EarthCode.GDPlus1Objects3) asyncObjectsList.addObject("Plus1", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.25), (runtimeScene) => (gdjs.EarthCode.asyncCallback11083892(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.EarthCode.asyncCallback10268884 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Doge_Action__Default_Pick_"), gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects3);

gdjs.copyArray(asyncObjectsList.getObjects("Doge_IDLE__Default_Pick_"), gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects3);

gdjs.EarthCode.GDPlus1Objects3.length = 0;

{for(var i = 0, len = gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects3.length ;i < len;++i) {
    gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects3[i].hide();
}
}{for(var i = 0, len = gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects3.length ;i < len;++i) {
    gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects3[i].hide(false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDPlus1Objects3Objects, gdjs.randomFloatInRange(560, 700), gdjs.randomFloatInRange(670, 770), "Things that need to be on top of text");
}
{ //Subevents
gdjs.EarthCode.eventsList5(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.EarthCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects2) asyncObjectsList.addObject("Doge_Action__Default_Pick_", obj);
for (const obj of gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects2) asyncObjectsList.addObject("Doge_IDLE__Default_Pick_", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.EarthCode.asyncCallback10268884(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.EarthCode.eventsList7 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Doge_Button"), gdjs.EarthCode.GDDoge_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDDoge_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDDoge_9595ButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDDoge_9595ButtonObjects2[k] = gdjs.EarthCode.GDDoge_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDDoge_9595ButtonObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Doge_Action__Default_Pick_"), gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects2);
gdjs.copyArray(runtimeScene.getObjects("Doge_IDLE__Default_Pick_"), gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects2);
{for(var i = 0, len = gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects2.length ;i < len;++i) {
    gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects2.length ;i < len;++i) {
    gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects2[i].hide(false);
}
}
{ //Subevents
gdjs.EarthCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11013420);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Doge_Action__Default_Pick_"), gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects2);
gdjs.copyArray(runtimeScene.getObjects("Doge_IDLE__Default_Pick_"), gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects2);
{for(var i = 0, len = gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects2.length ;i < len;++i) {
    gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects2.length ;i < len;++i) {
    gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects2[i].hide(false);
}
}
{ //Subevents
gdjs.EarthCode.eventsList6(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("DogeCoin_Amount"), gdjs.EarthCode.GDDogeCoin_9595AmountObjects2);
{for(var i = 0, len = gdjs.EarthCode.GDDogeCoin_9595AmountObjects2.length ;i < len;++i) {
    gdjs.EarthCode.GDDogeCoin_9595AmountObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.common.floorTo(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), 0)));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Upgrade_Button"), gdjs.EarthCode.GDUpgrade_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDUpgrade_9595ButtonObjects1.length;i<l;++i) {
    if ( gdjs.EarthCode.GDUpgrade_9595ButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDUpgrade_9595ButtonObjects1[k] = gdjs.EarthCode.GDUpgrade_9595ButtonObjects1[i];
        ++k;
    }
}
gdjs.EarthCode.GDUpgrade_9595ButtonObjects1.length = k;
if (isConditionTrue_0) {
}

}


};gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDMoon_95959595RocketObjects2Objects = Hashtable.newFrom({"Moon_Rocket": gdjs.EarthCode.GDMoon_9595RocketObjects2});
gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDSlave_95959595Kittens2Objects2Objects = Hashtable.newFrom({"Slave_Kittens2": gdjs.EarthCode.GDSlave_9595Kittens2Objects2});
gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDDogeKennel_95959595Base_95959595ProperObjects2Objects = Hashtable.newFrom({"DogeKennel_Base_Proper": gdjs.EarthCode.GDDogeKennel_9595Base_9595ProperObjects2});
gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDShibe_95959595AnimObjects2Objects = Hashtable.newFrom({"Shibe_Anim": gdjs.EarthCode.GDShibe_9595AnimObjects2});
gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDMoon_95959595BaseObjects2Objects = Hashtable.newFrom({"Moon_Base": gdjs.EarthCode.GDMoon_9595BaseObjects2});
gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDTime_95959595Machine_95959595AnimObjects1Objects = Hashtable.newFrom({"Time_Machine_Anim": gdjs.EarthCode.GDTime_9595Machine_9595AnimObjects1});
gdjs.EarthCode.eventsList8 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Upgrade4") > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild("Timer"));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(109);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade4");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild("NumberBought")) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10946612);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade4");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy_Button__Moon_Rocket"), gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2[k] = gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild("Cost"));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Moon_Rocket_Price_TEXT"), gdjs.EarthCode.GDMoon_9595Rocket_9595Price_9595TEXTObjects2);
gdjs.EarthCode.GDMoon_9595RocketObjects2.length = 0;

{runtimeScene.getScene().getVariables().getFromIndex(0).sub(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild("Cost")));
}{runtimeScene.getScene().getVariables().getFromIndex(4).getChild("NumberBought").add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(4).getChild("Timer").setNumber(1 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild("NumberBought")));
}{runtimeScene.getScene().getVariables().getFromIndex(4).getChild("Cost").setNumber(Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild("Cost")) * 1.1));
}{for(var i = 0, len = gdjs.EarthCode.GDMoon_9595Rocket_9595Price_9595TEXTObjects2.length ;i < len;++i) {
    gdjs.EarthCode.GDMoon_9595Rocket_9595Price_9595TEXTObjects2[i].getBehavior("Text").setText("Moon Rocket Price: \n" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild("Cost"))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDMoon_95959595RocketObjects2Objects, gdjs.randomInRange(300, 1200), gdjs.randomInRange(300, 900), "Logos/Images");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Buy_Button__Slave_Kittens"), gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2[k] = gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Cost"));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Slave_Kittens"), gdjs.EarthCode.GDSlave_9595KittensObjects2);
gdjs.EarthCode.GDSlave_9595Kittens2Objects2.length = 0;

{runtimeScene.getScene().getVariables().getFromIndex(0).sub(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Cost")));
}{runtimeScene.getScene().getVariables().getFromIndex(3).getChild("NumberBought").add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Timer").setNumber(1 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("NumberBought")));
}{runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Cost").setNumber(Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Cost")) * 1.1));
}{for(var i = 0, len = gdjs.EarthCode.GDSlave_9595KittensObjects2.length ;i < len;++i) {
    gdjs.EarthCode.GDSlave_9595KittensObjects2[i].getBehavior("Text").setText("Slave Kitten Price: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Cost"))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDSlave_95959595Kittens2Objects2Objects, gdjs.randomInRange(300, 1200), gdjs.randomInRange(300, 900), "Logos/Images");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("NumberBought")) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10869444);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade3");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Upgrade3") > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Timer"));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(13);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade3");
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Upgrade2") > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Timer"));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(3.5);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade2");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("NumberBought")) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9419388);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade2");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy_Button__Doge_Kennel"), gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2[k] = gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Cost"));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Kennel"), gdjs.EarthCode.GDKennelObjects2);
gdjs.EarthCode.GDDogeKennel_9595Base_9595ProperObjects2.length = 0;

{runtimeScene.getScene().getVariables().getFromIndex(0).sub(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Cost")));
}{runtimeScene.getScene().getVariables().getFromIndex(2).getChild("NumberBought").add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Timer").setNumber(1 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("NumberBought")));
}{runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Cost").setNumber(Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Cost")) * 1.1));
}{for(var i = 0, len = gdjs.EarthCode.GDKennelObjects2.length ;i < len;++i) {
    gdjs.EarthCode.GDKennelObjects2[i].getBehavior("Text").setText("Doge Kennel\nPrice: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Cost"))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDDogeKennel_95959595Base_95959595ProperObjects2Objects, gdjs.randomInRange(300, 1200), gdjs.randomInRange(300, 900), "Logos/Images");
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Upgrade1") > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Timer"));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(0.25);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade1");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("NumberBought")) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10972388);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade1");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy_Button__Mining_Shibe_"), gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2[k] = gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Cost"));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Shibe"), gdjs.EarthCode.GDShibeObjects2);
gdjs.EarthCode.GDShibe_9595AnimObjects2.length = 0;

{runtimeScene.getScene().getVariables().getFromIndex(0).sub(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Cost")));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild("NumberBought").add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Timer").setNumber(1 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("NumberBought")));
}{runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Cost").setNumber(Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Cost")) * 1.1));
}{for(var i = 0, len = gdjs.EarthCode.GDShibeObjects2.length ;i < len;++i) {
    gdjs.EarthCode.GDShibeObjects2[i].getBehavior("Text").setText("Mining Shibe\nPrice: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Cost"))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDShibe_95959595AnimObjects2Objects, gdjs.randomInRange(300, 1200), gdjs.randomInRange(300, 900), "Logos/Images");
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Upgrade5") > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5).getChild("Timer"));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(5000);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade5");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5).getChild("NumberBought")) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9428612);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade5");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy_Button__Moon_Base"), gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2[k] = gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5).getChild("Cost"));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Moon_Base_Text"), gdjs.EarthCode.GDMoon_9595Base_9595TextObjects2);
gdjs.EarthCode.GDMoon_9595BaseObjects2.length = 0;

{runtimeScene.getScene().getVariables().getFromIndex(0).sub(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5).getChild("Cost")));
}{runtimeScene.getScene().getVariables().getFromIndex(5).getChild("NumberBought").add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(5).getChild("Timer").setNumber(1 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5).getChild("NumberBought")));
}{runtimeScene.getScene().getVariables().getFromIndex(5).getChild("Cost").setNumber(Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5).getChild("Cost")) * 1.1));
}{for(var i = 0, len = gdjs.EarthCode.GDMoon_9595Base_9595TextObjects2.length ;i < len;++i) {
    gdjs.EarthCode.GDMoon_9595Base_9595TextObjects2[i].getBehavior("Text").setText("Moon Base\nPrice: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5).getChild("Cost"))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDMoon_95959595BaseObjects2Objects, gdjs.randomInRange(300, 1200), gdjs.randomInRange(300, 900), "Logos/Images");
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Upgrade6") > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getChild("Timer"));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(549215);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade6");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getChild("NumberBought")) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12206308);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Upgrade6");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy_Button__Time_Machine_Mining_Rig"), gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects1.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects1[k] = gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects1[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getChild("Cost"));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Time_Machine_Mining_Rig_Text"), gdjs.EarthCode.GDTime_9595Machine_9595Mining_9595Rig_9595TextObjects1);
gdjs.EarthCode.GDTime_9595Machine_9595AnimObjects1.length = 0;

{runtimeScene.getScene().getVariables().getFromIndex(0).sub(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getChild("Cost")));
}{runtimeScene.getScene().getVariables().getFromIndex(6).getChild("NumberBought").add(1);
}{runtimeScene.getScene().getVariables().getFromIndex(6).getChild("Timer").setNumber(1 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getChild("NumberBought")));
}{runtimeScene.getScene().getVariables().getFromIndex(6).getChild("Cost").setNumber(Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getChild("Cost")) * 1.1));
}{for(var i = 0, len = gdjs.EarthCode.GDTime_9595Machine_9595Mining_9595Rig_9595TextObjects1.length ;i < len;++i) {
    gdjs.EarthCode.GDTime_9595Machine_9595Mining_9595Rig_9595TextObjects1[i].getBehavior("Text").setText("Time Machine Mining Rig\nPrice: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getChild("Cost"))));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.EarthCode.mapOfGDgdjs_9546EarthCode_9546GDTime_95959595Machine_95959595AnimObjects1Objects, gdjs.randomInRange(300, 1200), gdjs.randomInRange(300, 900), "Logos/Images");
}}

}


};gdjs.EarthCode.asyncCallback11490324 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("DPS_Amount"), gdjs.EarthCode.GDDPS_9595AmountObjects3);
{for(var i = 0, len = gdjs.EarthCode.GDDPS_9595AmountObjects3.length ;i < len;++i) {
    gdjs.EarthCode.GDDPS_9595AmountObjects3[i].getBehavior("Text").setText((gdjs.evtTools.common.toString((((((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("NumberBought")) * 0.25) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("NumberBought")) * 3.5)) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("NumberBought")) * 13)) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild("NumberBought")) * 109)) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5).getChild("NumberBought")) * 5000)) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getChild("NumberBought")) * 549215))));
}
}}
gdjs.EarthCode.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.EarthCode.asyncCallback11490324(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.EarthCode.eventsList10 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.EarthCode.eventsList9(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Buy_Button__Slave_Kittens"), gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2);
gdjs.copyArray(runtimeScene.getObjects("Buy_Sound_Toggle"), gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2[k] = gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[k] = gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2.length = k;
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Cost"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8109404);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ka-ching.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy_Button__Doge_Kennel"), gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2);
gdjs.copyArray(runtimeScene.getObjects("Buy_Sound_Toggle"), gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2[k] = gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Cost"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[k] = gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2.length = k;
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11337356);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ka-ching.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy_Button__Mining_Shibe_"), gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2);
gdjs.copyArray(runtimeScene.getObjects("Buy_Sound_Toggle"), gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2[k] = gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[k] = gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2.length = k;
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Cost"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10997284);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ka-ching.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy_Button__Moon_Rocket"), gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2);
gdjs.copyArray(runtimeScene.getObjects("Buy_Sound_Toggle"), gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2[k] = gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[k] = gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2.length = k;
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild("Cost"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10435932);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ka-ching.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy_Button__Moon_Base"), gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2);
gdjs.copyArray(runtimeScene.getObjects("Buy_Sound_Toggle"), gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2[k] = gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[k] = gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2.length = k;
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5).getChild("Cost"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9743996);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ka-ching.mp3", false, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buy_Button__Time_Machine_Mining_Rig"), gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects2);
gdjs.copyArray(runtimeScene.getObjects("Buy_Sound_Toggle"), gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects2[k] = gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[k] = gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2.length = k;
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5).getChild("Cost"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10260300);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "ka-ching.mp3", false, 100, 1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Music_Toggle"), gdjs.EarthCode.GDMusic_9595ToggleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDMusic_9595ToggleObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDMusic_9595ToggleObjects2[i].HasJustBeenUnchecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDMusic_9595ToggleObjects2[k] = gdjs.EarthCode.GDMusic_9595ToggleObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDMusic_9595ToggleObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Doge_Button"), gdjs.EarthCode.GDDoge_9595ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hit_Sound_Toggle"), gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDDoge_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDDoge_9595ButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDDoge_9595ButtonObjects2[k] = gdjs.EarthCode.GDDoge_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDDoge_9595ButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects2.length;i<l;++i) {
    if ( gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects2[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects2[k] = gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects2[i];
        ++k;
    }
}
gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects2.length = k;
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "stone-breaking-made-with-Voicemod.mp3", false, 500, 1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("SquareWhiteSlider"), gdjs.EarthCode.GDSquareWhiteSliderObjects2);
{gdjs.evtTools.sound.setGlobalVolume(runtimeScene, (( gdjs.EarthCode.GDSquareWhiteSliderObjects2.length === 0 ) ? 0 :gdjs.EarthCode.GDSquareWhiteSliderObjects2[0].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Music_Toggle"), gdjs.EarthCode.GDMusic_9595ToggleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDMusic_9595ToggleObjects1.length;i<l;++i) {
    if ( gdjs.EarthCode.GDMusic_9595ToggleObjects1[i].IsChecked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDMusic_9595ToggleObjects1[k] = gdjs.EarthCode.GDMusic_9595ToggleObjects1[i];
        ++k;
    }
}
gdjs.EarthCode.GDMusic_9595ToggleObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8101732);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Earth.mp3", 1, false, 100, 1);
}}

}


};gdjs.EarthCode.eventsList11 = function(runtimeScene) {

};gdjs.EarthCode.eventsList12 = function(runtimeScene) {

{


gdjs.EarthCode.eventsList0(runtimeScene);
}


{


gdjs.EarthCode.eventsList7(runtimeScene);
}


{


gdjs.EarthCode.eventsList8(runtimeScene);
}


{


gdjs.EarthCode.eventsList10(runtimeScene);
}


{


gdjs.EarthCode.eventsList11(runtimeScene);
}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Save_Game_Button"), gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1.length;i<l;++i) {
    if ( gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1[k] = gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1[i];
        ++k;
    }
}
gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeNumberInJSONFile("Currencies", "DogeCoin", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Save_Game_Button"), gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1.length;i<l;++i) {
    if ( gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1[k] = gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1[i];
        ++k;
    }
}
gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeNumberInJSONFile("Helpers", "Moon Rockets Cost", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild("Cost")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Helpers", "Moon Rockets", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getChild("NumberBought")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Helpers", "Doge Kennels Cost", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Cost")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Helpers", "Doge Kennels", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2).getChild("NumberBought")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Helpers", "Slave Kittens", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("NumberBought")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Helpers", "Slave Kittens Cost", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Cost")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Helpers", "Mining Shibes Cost", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Cost")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Helpers", "Mining Shibes", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1).getChild("NumberBought")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Helpers", "Moon Base Cost", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5).getChild("Cost")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Helpers", "Moon Base", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5).getChild("NumberBought")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Helpers", "Time Machine Cost", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getChild("Cost")));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Helpers", "Time Machines", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getChild("NumberBought")));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Load_Game_Button"), gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects1.length;i<l;++i) {
    if ( gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects1[k] = gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects1[i];
        ++k;
    }
}
gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("Helpers", "Mining Shibes", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(1).getChild("NumberBought"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("Helpers", "Mining Shibes Cost", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(1).getChild("Cost"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("Helpers", "Moon Rockets Cost", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(4).getChild("Cost"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("Helpers", "Moon Rockets", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(4).getChild("NumberBought"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("Helpers", "Doge Kennels Cost", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(2).getChild("Cost"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("Helpers", "Doge Kennels", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(2).getChild("NumberBought"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("Helpers", "Slave Kittens", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(3).getChild("NumberBought"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("Helpers", "Slave Kittens Cost", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(3).getChild("Cost"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("Currencies", "DogeCoin", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0));
}{gdjs.evtTools.storage.readNumberFromJSONFile("Helpers", "Moon Base", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(5).getChild("NumberBought"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("Helpers", "Moon Base Cost", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(5).getChild("Cost"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("Helpers", "Time Machine Cost", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(6).getChild("Cost"));
}{gdjs.evtTools.storage.readNumberFromJSONFile("Helpers", "Time Machines", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(6).getChild("NumberBought"));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Reset_Game_Button"), gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects1.length;i<l;++i) {
    if ( gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects1[k] = gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects1[i];
        ++k;
    }
}
gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.storage.deleteElementFromJSONFile("Currencies", "DogeCoin");
}{gdjs.evtTools.storage.deleteElementFromJSONFile("Helpers", "Slave Kittens");
}{gdjs.evtTools.storage.deleteElementFromJSONFile("Helpers", "Doge Kennels");
}{gdjs.evtTools.storage.deleteElementFromJSONFile("Helpers", "Mining Shibes");
}{gdjs.evtTools.storage.deleteElementFromJSONFile("Helpers", "Moon Rockets");
}{gdjs.evtTools.storage.deleteElementFromJSONFile("Helpers", "Moon Rockets Cost");
}{gdjs.evtTools.storage.deleteElementFromJSONFile("Helpers", "Mining Shibes Cost");
}{gdjs.evtTools.storage.deleteElementFromJSONFile("Helpers", "Doge Kennels Cost");
}{gdjs.evtTools.storage.deleteElementFromJSONFile("Helpers", "Slave Kittens Cost");
}{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}{gdjs.evtTools.storage.deleteElementFromJSONFile("Helpers", "Moon Base Cost");
}{gdjs.evtTools.storage.deleteElementFromJSONFile("Helpers", "Moon Base");
}{gdjs.evtTools.storage.deleteElementFromJSONFile("Helpers", "Time Machine Cost");
}{gdjs.evtTools.storage.deleteElementFromJSONFile("Helpers", "Time Machines");
}}

}


};

gdjs.EarthCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.EarthCode.GDBackground_9595_9595Earth_9595Objects1.length = 0;
gdjs.EarthCode.GDBackground_9595_9595Earth_9595Objects2.length = 0;
gdjs.EarthCode.GDBackground_9595_9595Earth_9595Objects3.length = 0;
gdjs.EarthCode.GDBackground_9595_9595Earth_9595Objects4.length = 0;
gdjs.EarthCode.GDBackground_9595_9595Earth_9595Objects5.length = 0;
gdjs.EarthCode.GDEarth_9595UIObjects1.length = 0;
gdjs.EarthCode.GDEarth_9595UIObjects2.length = 0;
gdjs.EarthCode.GDEarth_9595UIObjects3.length = 0;
gdjs.EarthCode.GDEarth_9595UIObjects4.length = 0;
gdjs.EarthCode.GDEarth_9595UIObjects5.length = 0;
gdjs.EarthCode.GDReddit_9595ButtonObjects1.length = 0;
gdjs.EarthCode.GDReddit_9595ButtonObjects2.length = 0;
gdjs.EarthCode.GDReddit_9595ButtonObjects3.length = 0;
gdjs.EarthCode.GDReddit_9595ButtonObjects4.length = 0;
gdjs.EarthCode.GDReddit_9595ButtonObjects5.length = 0;
gdjs.EarthCode.GDReddit_9595LogoObjects1.length = 0;
gdjs.EarthCode.GDReddit_9595LogoObjects2.length = 0;
gdjs.EarthCode.GDReddit_9595LogoObjects3.length = 0;
gdjs.EarthCode.GDReddit_9595LogoObjects4.length = 0;
gdjs.EarthCode.GDReddit_9595LogoObjects5.length = 0;
gdjs.EarthCode.GDDiscord_9595ButtonObjects1.length = 0;
gdjs.EarthCode.GDDiscord_9595ButtonObjects2.length = 0;
gdjs.EarthCode.GDDiscord_9595ButtonObjects3.length = 0;
gdjs.EarthCode.GDDiscord_9595ButtonObjects4.length = 0;
gdjs.EarthCode.GDDiscord_9595ButtonObjects5.length = 0;
gdjs.EarthCode.GDDiscord_9595LogoObjects1.length = 0;
gdjs.EarthCode.GDDiscord_9595LogoObjects2.length = 0;
gdjs.EarthCode.GDDiscord_9595LogoObjects3.length = 0;
gdjs.EarthCode.GDDiscord_9595LogoObjects4.length = 0;
gdjs.EarthCode.GDDiscord_9595LogoObjects5.length = 0;
gdjs.EarthCode.GDSteamGroup_9595ButtonObjects1.length = 0;
gdjs.EarthCode.GDSteamGroup_9595ButtonObjects2.length = 0;
gdjs.EarthCode.GDSteamGroup_9595ButtonObjects3.length = 0;
gdjs.EarthCode.GDSteamGroup_9595ButtonObjects4.length = 0;
gdjs.EarthCode.GDSteamGroup_9595ButtonObjects5.length = 0;
gdjs.EarthCode.GDSteamGroup_9595LogoObjects1.length = 0;
gdjs.EarthCode.GDSteamGroup_9595LogoObjects2.length = 0;
gdjs.EarthCode.GDSteamGroup_9595LogoObjects3.length = 0;
gdjs.EarthCode.GDSteamGroup_9595LogoObjects4.length = 0;
gdjs.EarthCode.GDSteamGroup_9595LogoObjects5.length = 0;
gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects1.length = 0;
gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects2.length = 0;
gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects3.length = 0;
gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects4.length = 0;
gdjs.EarthCode.GDItch_9595IO_9595ButtonObjects5.length = 0;
gdjs.EarthCode.GDItch_9595IO_9595LogoObjects1.length = 0;
gdjs.EarthCode.GDItch_9595IO_9595LogoObjects2.length = 0;
gdjs.EarthCode.GDItch_9595IO_9595LogoObjects3.length = 0;
gdjs.EarthCode.GDItch_9595IO_9595LogoObjects4.length = 0;
gdjs.EarthCode.GDItch_9595IO_9595LogoObjects5.length = 0;
gdjs.EarthCode.GDGameJolt_9595ButtonObjects1.length = 0;
gdjs.EarthCode.GDGameJolt_9595ButtonObjects2.length = 0;
gdjs.EarthCode.GDGameJolt_9595ButtonObjects3.length = 0;
gdjs.EarthCode.GDGameJolt_9595ButtonObjects4.length = 0;
gdjs.EarthCode.GDGameJolt_9595ButtonObjects5.length = 0;
gdjs.EarthCode.GDGameJolt_9595LogoObjects1.length = 0;
gdjs.EarthCode.GDGameJolt_9595LogoObjects2.length = 0;
gdjs.EarthCode.GDGameJolt_9595LogoObjects3.length = 0;
gdjs.EarthCode.GDGameJolt_9595LogoObjects4.length = 0;
gdjs.EarthCode.GDGameJolt_9595LogoObjects5.length = 0;
gdjs.EarthCode.GDSocial_9595Media_9595TextObjects1.length = 0;
gdjs.EarthCode.GDSocial_9595Media_9595TextObjects2.length = 0;
gdjs.EarthCode.GDSocial_9595Media_9595TextObjects3.length = 0;
gdjs.EarthCode.GDSocial_9595Media_9595TextObjects4.length = 0;
gdjs.EarthCode.GDSocial_9595Media_9595TextObjects5.length = 0;
gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects1.length = 0;
gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects2.length = 0;
gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects3.length = 0;
gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects4.length = 0;
gdjs.EarthCode.GDDoge_9595IDLE_9595_9595Default_9595Pick_9595Objects5.length = 0;
gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects1.length = 0;
gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects2.length = 0;
gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects3.length = 0;
gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects4.length = 0;
gdjs.EarthCode.GDDoge_9595Action_9595_9595Default_9595Pick_9595Objects5.length = 0;
gdjs.EarthCode.GDDoge_9595ButtonObjects1.length = 0;
gdjs.EarthCode.GDDoge_9595ButtonObjects2.length = 0;
gdjs.EarthCode.GDDoge_9595ButtonObjects3.length = 0;
gdjs.EarthCode.GDDoge_9595ButtonObjects4.length = 0;
gdjs.EarthCode.GDDoge_9595ButtonObjects5.length = 0;
gdjs.EarthCode.GDDogeCoinsObjects1.length = 0;
gdjs.EarthCode.GDDogeCoinsObjects2.length = 0;
gdjs.EarthCode.GDDogeCoinsObjects3.length = 0;
gdjs.EarthCode.GDDogeCoinsObjects4.length = 0;
gdjs.EarthCode.GDDogeCoinsObjects5.length = 0;
gdjs.EarthCode.GDDogeCoin_9595LogoObjects1.length = 0;
gdjs.EarthCode.GDDogeCoin_9595LogoObjects2.length = 0;
gdjs.EarthCode.GDDogeCoin_9595LogoObjects3.length = 0;
gdjs.EarthCode.GDDogeCoin_9595LogoObjects4.length = 0;
gdjs.EarthCode.GDDogeCoin_9595LogoObjects5.length = 0;
gdjs.EarthCode.GDDogeCoin_9595AmountObjects1.length = 0;
gdjs.EarthCode.GDDogeCoin_9595AmountObjects2.length = 0;
gdjs.EarthCode.GDDogeCoin_9595AmountObjects3.length = 0;
gdjs.EarthCode.GDDogeCoin_9595AmountObjects4.length = 0;
gdjs.EarthCode.GDDogeCoin_9595AmountObjects5.length = 0;
gdjs.EarthCode.GDEarth_9595ButtonObjects1.length = 0;
gdjs.EarthCode.GDEarth_9595ButtonObjects2.length = 0;
gdjs.EarthCode.GDEarth_9595ButtonObjects3.length = 0;
gdjs.EarthCode.GDEarth_9595ButtonObjects4.length = 0;
gdjs.EarthCode.GDEarth_9595ButtonObjects5.length = 0;
gdjs.EarthCode.GDThingaMaBobbaObjects1.length = 0;
gdjs.EarthCode.GDThingaMaBobbaObjects2.length = 0;
gdjs.EarthCode.GDThingaMaBobbaObjects3.length = 0;
gdjs.EarthCode.GDThingaMaBobbaObjects4.length = 0;
gdjs.EarthCode.GDThingaMaBobbaObjects5.length = 0;
gdjs.EarthCode.GDShibe_9595AnimObjects1.length = 0;
gdjs.EarthCode.GDShibe_9595AnimObjects2.length = 0;
gdjs.EarthCode.GDShibe_9595AnimObjects3.length = 0;
gdjs.EarthCode.GDShibe_9595AnimObjects4.length = 0;
gdjs.EarthCode.GDShibe_9595AnimObjects5.length = 0;
gdjs.EarthCode.GDShibeObjects1.length = 0;
gdjs.EarthCode.GDShibeObjects2.length = 0;
gdjs.EarthCode.GDShibeObjects3.length = 0;
gdjs.EarthCode.GDShibeObjects4.length = 0;
gdjs.EarthCode.GDShibeObjects5.length = 0;
gdjs.EarthCode.GDShibe_9595Alt_9595TextObjects1.length = 0;
gdjs.EarthCode.GDShibe_9595Alt_9595TextObjects2.length = 0;
gdjs.EarthCode.GDShibe_9595Alt_9595TextObjects3.length = 0;
gdjs.EarthCode.GDShibe_9595Alt_9595TextObjects4.length = 0;
gdjs.EarthCode.GDShibe_9595Alt_9595TextObjects5.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects1.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects2.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects3.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects4.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Mining_9595Shibe_9595Objects5.length = 0;
gdjs.EarthCode.GDSquareWhiteSliderObjects1.length = 0;
gdjs.EarthCode.GDSquareWhiteSliderObjects2.length = 0;
gdjs.EarthCode.GDSquareWhiteSliderObjects3.length = 0;
gdjs.EarthCode.GDSquareWhiteSliderObjects4.length = 0;
gdjs.EarthCode.GDSquareWhiteSliderObjects5.length = 0;
gdjs.EarthCode.GDVolume_9595TextObjects1.length = 0;
gdjs.EarthCode.GDVolume_9595TextObjects2.length = 0;
gdjs.EarthCode.GDVolume_9595TextObjects3.length = 0;
gdjs.EarthCode.GDVolume_9595TextObjects4.length = 0;
gdjs.EarthCode.GDVolume_9595TextObjects5.length = 0;
gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects1.length = 0;
gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects2.length = 0;
gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects3.length = 0;
gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects4.length = 0;
gdjs.EarthCode.GDHit_9595Sound_9595ToggleObjects5.length = 0;
gdjs.EarthCode.GDEnable_9595Rock_9595Hitting_9595TextObjects1.length = 0;
gdjs.EarthCode.GDEnable_9595Rock_9595Hitting_9595TextObjects2.length = 0;
gdjs.EarthCode.GDEnable_9595Rock_9595Hitting_9595TextObjects3.length = 0;
gdjs.EarthCode.GDEnable_9595Rock_9595Hitting_9595TextObjects4.length = 0;
gdjs.EarthCode.GDEnable_9595Rock_9595Hitting_9595TextObjects5.length = 0;
gdjs.EarthCode.GDTotal_9595DPSObjects1.length = 0;
gdjs.EarthCode.GDTotal_9595DPSObjects2.length = 0;
gdjs.EarthCode.GDTotal_9595DPSObjects3.length = 0;
gdjs.EarthCode.GDTotal_9595DPSObjects4.length = 0;
gdjs.EarthCode.GDTotal_9595DPSObjects5.length = 0;
gdjs.EarthCode.GDDPS_9595LogoObjects1.length = 0;
gdjs.EarthCode.GDDPS_9595LogoObjects2.length = 0;
gdjs.EarthCode.GDDPS_9595LogoObjects3.length = 0;
gdjs.EarthCode.GDDPS_9595LogoObjects4.length = 0;
gdjs.EarthCode.GDDPS_9595LogoObjects5.length = 0;
gdjs.EarthCode.GDDPS_9595AmountObjects1.length = 0;
gdjs.EarthCode.GDDPS_9595AmountObjects2.length = 0;
gdjs.EarthCode.GDDPS_9595AmountObjects3.length = 0;
gdjs.EarthCode.GDDPS_9595AmountObjects4.length = 0;
gdjs.EarthCode.GDDPS_9595AmountObjects5.length = 0;
gdjs.EarthCode.GDMining_9595Shibe_9595DPSObjects1.length = 0;
gdjs.EarthCode.GDMining_9595Shibe_9595DPSObjects2.length = 0;
gdjs.EarthCode.GDMining_9595Shibe_9595DPSObjects3.length = 0;
gdjs.EarthCode.GDMining_9595Shibe_9595DPSObjects4.length = 0;
gdjs.EarthCode.GDMining_9595Shibe_9595DPSObjects5.length = 0;
gdjs.EarthCode.GDMusic_9595ToggleObjects1.length = 0;
gdjs.EarthCode.GDMusic_9595ToggleObjects2.length = 0;
gdjs.EarthCode.GDMusic_9595ToggleObjects3.length = 0;
gdjs.EarthCode.GDMusic_9595ToggleObjects4.length = 0;
gdjs.EarthCode.GDMusic_9595ToggleObjects5.length = 0;
gdjs.EarthCode.GDToggle_9595Music_9595TextObjects1.length = 0;
gdjs.EarthCode.GDToggle_9595Music_9595TextObjects2.length = 0;
gdjs.EarthCode.GDToggle_9595Music_9595TextObjects3.length = 0;
gdjs.EarthCode.GDToggle_9595Music_9595TextObjects4.length = 0;
gdjs.EarthCode.GDToggle_9595Music_9595TextObjects5.length = 0;
gdjs.EarthCode.GDDoge_9595KennelsObjects1.length = 0;
gdjs.EarthCode.GDDoge_9595KennelsObjects2.length = 0;
gdjs.EarthCode.GDDoge_9595KennelsObjects3.length = 0;
gdjs.EarthCode.GDDoge_9595KennelsObjects4.length = 0;
gdjs.EarthCode.GDDoge_9595KennelsObjects5.length = 0;
gdjs.EarthCode.GDKennelObjects1.length = 0;
gdjs.EarthCode.GDKennelObjects2.length = 0;
gdjs.EarthCode.GDKennelObjects3.length = 0;
gdjs.EarthCode.GDKennelObjects4.length = 0;
gdjs.EarthCode.GDKennelObjects5.length = 0;
gdjs.EarthCode.GDKennel_9595Alt_9595TextObjects1.length = 0;
gdjs.EarthCode.GDKennel_9595Alt_9595TextObjects2.length = 0;
gdjs.EarthCode.GDKennel_9595Alt_9595TextObjects3.length = 0;
gdjs.EarthCode.GDKennel_9595Alt_9595TextObjects4.length = 0;
gdjs.EarthCode.GDKennel_9595Alt_9595TextObjects5.length = 0;
gdjs.EarthCode.GDDoge_9595Kennel_9595DPSObjects1.length = 0;
gdjs.EarthCode.GDDoge_9595Kennel_9595DPSObjects2.length = 0;
gdjs.EarthCode.GDDoge_9595Kennel_9595DPSObjects3.length = 0;
gdjs.EarthCode.GDDoge_9595Kennel_9595DPSObjects4.length = 0;
gdjs.EarthCode.GDDoge_9595Kennel_9595DPSObjects5.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects1.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects2.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects3.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects4.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Doge_9595KennelObjects5.length = 0;
gdjs.EarthCode.GDDogeKennel_9595Base_9595ProperObjects1.length = 0;
gdjs.EarthCode.GDDogeKennel_9595Base_9595ProperObjects2.length = 0;
gdjs.EarthCode.GDDogeKennel_9595Base_9595ProperObjects3.length = 0;
gdjs.EarthCode.GDDogeKennel_9595Base_9595ProperObjects4.length = 0;
gdjs.EarthCode.GDDogeKennel_9595Base_9595ProperObjects5.length = 0;
gdjs.EarthCode.GDSlave_9595KittensObjects1.length = 0;
gdjs.EarthCode.GDSlave_9595KittensObjects2.length = 0;
gdjs.EarthCode.GDSlave_9595KittensObjects3.length = 0;
gdjs.EarthCode.GDSlave_9595KittensObjects4.length = 0;
gdjs.EarthCode.GDSlave_9595KittensObjects5.length = 0;
gdjs.EarthCode.GDSlave_9595Kittens2Objects1.length = 0;
gdjs.EarthCode.GDSlave_9595Kittens2Objects2.length = 0;
gdjs.EarthCode.GDSlave_9595Kittens2Objects3.length = 0;
gdjs.EarthCode.GDSlave_9595Kittens2Objects4.length = 0;
gdjs.EarthCode.GDSlave_9595Kittens2Objects5.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects1.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects2.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects3.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects4.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Slave_9595KittensObjects5.length = 0;
gdjs.EarthCode.GDSlave_9595Kitten_9595Alt_9595TextObjects1.length = 0;
gdjs.EarthCode.GDSlave_9595Kitten_9595Alt_9595TextObjects2.length = 0;
gdjs.EarthCode.GDSlave_9595Kitten_9595Alt_9595TextObjects3.length = 0;
gdjs.EarthCode.GDSlave_9595Kitten_9595Alt_9595TextObjects4.length = 0;
gdjs.EarthCode.GDSlave_9595Kitten_9595Alt_9595TextObjects5.length = 0;
gdjs.EarthCode.GDSlave_9595Kittten_9595DPSObjects1.length = 0;
gdjs.EarthCode.GDSlave_9595Kittten_9595DPSObjects2.length = 0;
gdjs.EarthCode.GDSlave_9595Kittten_9595DPSObjects3.length = 0;
gdjs.EarthCode.GDSlave_9595Kittten_9595DPSObjects4.length = 0;
gdjs.EarthCode.GDSlave_9595Kittten_9595DPSObjects5.length = 0;
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects1.length = 0;
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects2.length = 0;
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects3.length = 0;
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects4.length = 0;
gdjs.EarthCode.GDBuy_9595Sound_9595ToggleObjects5.length = 0;
gdjs.EarthCode.GDToggle_9595Buy_9595Sounds_9595TextObjects1.length = 0;
gdjs.EarthCode.GDToggle_9595Buy_9595Sounds_9595TextObjects2.length = 0;
gdjs.EarthCode.GDToggle_9595Buy_9595Sounds_9595TextObjects3.length = 0;
gdjs.EarthCode.GDToggle_9595Buy_9595Sounds_9595TextObjects4.length = 0;
gdjs.EarthCode.GDToggle_9595Buy_9595Sounds_9595TextObjects5.length = 0;
gdjs.EarthCode.GDMoon_9595RocketObjects1.length = 0;
gdjs.EarthCode.GDMoon_9595RocketObjects2.length = 0;
gdjs.EarthCode.GDMoon_9595RocketObjects3.length = 0;
gdjs.EarthCode.GDMoon_9595RocketObjects4.length = 0;
gdjs.EarthCode.GDMoon_9595RocketObjects5.length = 0;
gdjs.EarthCode.GDMoon_9595Rocket_9595Price_9595TEXTObjects1.length = 0;
gdjs.EarthCode.GDMoon_9595Rocket_9595Price_9595TEXTObjects2.length = 0;
gdjs.EarthCode.GDMoon_9595Rocket_9595Price_9595TEXTObjects3.length = 0;
gdjs.EarthCode.GDMoon_9595Rocket_9595Price_9595TEXTObjects4.length = 0;
gdjs.EarthCode.GDMoon_9595Rocket_9595Price_9595TEXTObjects5.length = 0;
gdjs.EarthCode.GDmoon_9595rocket_9595alt_9595textObjects1.length = 0;
gdjs.EarthCode.GDmoon_9595rocket_9595alt_9595textObjects2.length = 0;
gdjs.EarthCode.GDmoon_9595rocket_9595alt_9595textObjects3.length = 0;
gdjs.EarthCode.GDmoon_9595rocket_9595alt_9595textObjects4.length = 0;
gdjs.EarthCode.GDmoon_9595rocket_9595alt_9595textObjects5.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects1.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects2.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects3.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects4.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595RocketObjects5.length = 0;
gdjs.EarthCode.GDMoon_9595Rocket_9595DPSObjects1.length = 0;
gdjs.EarthCode.GDMoon_9595Rocket_9595DPSObjects2.length = 0;
gdjs.EarthCode.GDMoon_9595Rocket_9595DPSObjects3.length = 0;
gdjs.EarthCode.GDMoon_9595Rocket_9595DPSObjects4.length = 0;
gdjs.EarthCode.GDMoon_9595Rocket_9595DPSObjects5.length = 0;
gdjs.EarthCode.GDPlus1Objects1.length = 0;
gdjs.EarthCode.GDPlus1Objects2.length = 0;
gdjs.EarthCode.GDPlus1Objects3.length = 0;
gdjs.EarthCode.GDPlus1Objects4.length = 0;
gdjs.EarthCode.GDPlus1Objects5.length = 0;
gdjs.EarthCode.GDNot_9595AllowedObjects1.length = 0;
gdjs.EarthCode.GDNot_9595AllowedObjects2.length = 0;
gdjs.EarthCode.GDNot_9595AllowedObjects3.length = 0;
gdjs.EarthCode.GDNot_9595AllowedObjects4.length = 0;
gdjs.EarthCode.GDNot_9595AllowedObjects5.length = 0;
gdjs.EarthCode.GDUpgrade_9595ButtonObjects1.length = 0;
gdjs.EarthCode.GDUpgrade_9595ButtonObjects2.length = 0;
gdjs.EarthCode.GDUpgrade_9595ButtonObjects3.length = 0;
gdjs.EarthCode.GDUpgrade_9595ButtonObjects4.length = 0;
gdjs.EarthCode.GDUpgrade_9595ButtonObjects5.length = 0;
gdjs.EarthCode.GDHelpers_9595ButtonObjects1.length = 0;
gdjs.EarthCode.GDHelpers_9595ButtonObjects2.length = 0;
gdjs.EarthCode.GDHelpers_9595ButtonObjects3.length = 0;
gdjs.EarthCode.GDHelpers_9595ButtonObjects4.length = 0;
gdjs.EarthCode.GDHelpers_9595ButtonObjects5.length = 0;
gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects1.length = 0;
gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects2.length = 0;
gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects3.length = 0;
gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects4.length = 0;
gdjs.EarthCode.GDSave_9595Game_9595ButtonObjects5.length = 0;
gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects1.length = 0;
gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects2.length = 0;
gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects3.length = 0;
gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects4.length = 0;
gdjs.EarthCode.GDLoad_9595Game_9595ButtonObjects5.length = 0;
gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects1.length = 0;
gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects2.length = 0;
gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects3.length = 0;
gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects4.length = 0;
gdjs.EarthCode.GDReset_9595Game_9595ButtonObjects5.length = 0;
gdjs.EarthCode.GDMoon_9595BaseObjects1.length = 0;
gdjs.EarthCode.GDMoon_9595BaseObjects2.length = 0;
gdjs.EarthCode.GDMoon_9595BaseObjects3.length = 0;
gdjs.EarthCode.GDMoon_9595BaseObjects4.length = 0;
gdjs.EarthCode.GDMoon_9595BaseObjects5.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects1.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects2.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects3.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects4.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Moon_9595BaseObjects5.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595TextObjects1.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595TextObjects2.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595TextObjects3.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595TextObjects4.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595TextObjects5.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595Alt_9595TextObjects1.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595Alt_9595TextObjects2.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595Alt_9595TextObjects3.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595Alt_9595TextObjects4.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595Alt_9595TextObjects5.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595DPS_9595TextObjects1.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595DPS_9595TextObjects2.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595DPS_9595TextObjects3.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595DPS_9595TextObjects4.length = 0;
gdjs.EarthCode.GDMoon_9595Base_9595DPS_9595TextObjects5.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595AnimObjects1.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595AnimObjects2.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595AnimObjects3.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595AnimObjects4.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595AnimObjects5.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595Mining_9595Rig_9595TextObjects1.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595Mining_9595Rig_9595TextObjects2.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595Mining_9595Rig_9595TextObjects3.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595Mining_9595Rig_9595TextObjects4.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595Mining_9595Rig_9595TextObjects5.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595Alt_9595TextObjects1.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595Alt_9595TextObjects2.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595Alt_9595TextObjects3.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595Alt_9595TextObjects4.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595Alt_9595TextObjects5.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects1.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects2.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects3.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects4.length = 0;
gdjs.EarthCode.GDBuy_9595Button_9595_9595Time_9595Machine_9595Mining_9595RigObjects5.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595DPS_9595TextObjects1.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595DPS_9595TextObjects2.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595DPS_9595TextObjects3.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595DPS_9595TextObjects4.length = 0;
gdjs.EarthCode.GDTime_9595Machine_9595DPS_9595TextObjects5.length = 0;

gdjs.EarthCode.eventsList12(runtimeScene);

return;

}

gdjs['EarthCode'] = gdjs.EarthCode;
